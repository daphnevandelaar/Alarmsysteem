1. Include all libraries from the include folder to your arduino ide

2. Wire the Arduinos according to the wiring schemes in the wiringschemes folder

3. Transmitter folder, is the code to upload to the Arduino with transmitterconnected

4. Receiver folder, is the code to upload to the Arduino with receiver connected

5. Transmitter Arduino is connected to laptop to read data, 
   if you want it wireless you can connect the battery to the Vin pin on your Arduino.

6. Open the C# app and connect it with the Arduino, 
   check if the baudrate and COM ports are the same as yours. 

7. You can set the alarm off with the c# app



Made by:
Dirk-Jan de Beijer & Daphne van de Laar